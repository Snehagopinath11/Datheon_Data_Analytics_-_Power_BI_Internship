# Task 1: Superstore Sales Analysis

**Goal:** analyse purchase volume, monthly seasonality, category-wise revenue and discount sensitivity.

**Files:** `Superstore_Sales_Analysis.ipynb`, `superstore_sales.csv`

**Data cleaning:** the CSV has two extra tables (salespeople and returns) appended below the 9,994 orders; these were separated out. Dates were parsed, one duplicate row removed, and one missing postal code filled.

## Key findings
1. Sales rose from about $484K (2015) to $733K (2018); profit nearly doubled and margin improved from about 10% to 13%.
2. September, November and December deliver about 43% of annual sales.
3. Furniture has near-Technology revenue but only a 2.5% margin; Tables and Bookcases lose money.
4. Discounts above 20% are loss-making; the 50%+ band loses about $77K.
5. The Central region has a 7.9% margin versus 14.9% in the West.
6. The top 20% of customers generate about 48% of sales.
