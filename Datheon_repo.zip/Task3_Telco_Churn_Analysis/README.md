# Task 3: Telco Customer Churn & Retention

**Goal:** measure churn, build retention curves by contract, payment method and monthly charges, and find high-risk segments.

**Files:** `Telco_Churn_Analysis.ipynb`, `Telco-Customer-Churn.csv` (IBM Telco Customer Churn sample dataset, 7,043 customers)

**Methods:** tenure cohorts, Kaplan-Meier retention curves, churn heatmaps, segment risk table, logistic regression churn probability.

## Key findings
- Baseline churn 26.5%; 47.4% in the first 12 months.
- Month-to-month 42.7% vs two-year 2.8%.
- Fiber optic customers without tech support churn at 49.4% (57.5% if also month-to-month).
- Electronic-check payers churn at 45.3%, about 3x autopay customers (a targeting signal, not proof of cause).
- Model test ROC-AUC 0.84; the High-risk tier churns at 65%.
