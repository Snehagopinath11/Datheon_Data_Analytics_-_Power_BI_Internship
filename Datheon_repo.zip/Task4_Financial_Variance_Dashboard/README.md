# Task 4: Financial Variance Dashboard

**Goal:** model the income statement (Gross Sales, Discounts, Net Sales, COGS, Profit) and compare actuals to budget across segments, countries and products.

**Files**
- `star_schema/`: cleaned fact and dimension tables from the Microsoft Financial Sample dataset
- `Financial_Variance_Build_Guide.pdf`: model, DAX, waterfall chart and scenario sliders

**Important:** the dataset has no budget. Budget is built from two editable assumptions (5% planned discount, 82% target COGS ratio). Product is used as the manufacturing cost centre.

## Key findings
- Gross Sales $127.9M, Net Sales $118.7M, Profit $16.9M (14.2% margin).
- Enterprise: $19.6M net sales but a -$0.61M profit.
- Government is the main profit engine ($11.4M, 21.7% margin).
- Every product misses budget profit, mainly because COGS is 85.8% of net sales versus the 82% target.
