# Task 2: Superstore Power BI Dashboard

**Goal:** turn the Superstore data into an interactive executive dashboard (KPI cards, date and region slicers, treemaps, profitability matrix).

**Files**
- `star_schema/`: cleaned Fact_Orders, Dim_Customer, Dim_Product, Dim_Date and Dim_Geography
- `PowerBI_Build_Guide.pdf`: model relationships, DAX measures and visual layout

**Key DAX measures:** Total Sales, Total Profit, Profit Margin %, Total Orders, YoY Sales Growth %.

**Reference totals:** Sales $2,296,919 | Profit $286,409 | Margin 12.5% | Orders 5,009.
