# Datheon: Data Analytics & Power BI Internship

Practical work completed during my Data Analytics & Power BI internship at Datheon, covering exploratory analysis, customer retention, dashboard modelling and financial variance analysis.

**Tools:** Python (Pandas, Seaborn, Plotly, scikit-learn), Power BI, DAX, Power Query, Excel

| # | Task | Tools | Folder |
|---|------|-------|--------|
| 1 | Superstore sales analysis: seasonality, category revenue, discount sensitivity | Python, Pandas, Seaborn | [Task1_Superstore_Sales_Analysis](Task1_Superstore_Sales_Analysis) |
| 2 | Superstore executive dashboard: star schema, DAX, KPI cards, treemaps | Power BI, DAX, Power Query | [Task2_Superstore_PowerBI_Dashboard](Task2_Superstore_PowerBI_Dashboard) |
| 3 | Telco customer churn and retention curves | Python, Plotly, scikit-learn | [Task3_Telco_Churn_Analysis](Task3_Telco_Churn_Analysis) |
| 4 | Financial variance analysis: actual vs budget, waterfall, scenario sliders | Power BI, DAX | [Task4_Financial_Variance_Dashboard](Task4_Financial_Variance_Dashboard) |

## Highlights
- **Superstore:** sales grew about 51% from 2015 to 2018; discounts above 20% turn every order band loss-making; Furniture earns only a 2.5% margin.
- **Telco churn:** baseline churn is 26.5%; month-to-month contracts churn at 42.7% versus 2.8% on two-year plans; a logistic regression reaches a test ROC-AUC of 0.84.
- **Financial variance:** Enterprise segment loses money (-3.1% margin) while Government drives most profit.

## How to run the notebooks
Each notebook sits in the same folder as its CSV. Open it in Jupyter, VS Code or Google Colab and run all cells.

## Contact
[LinkedIn](https://www.linkedin.com/in/snehagopinath-c-4734a9224)
