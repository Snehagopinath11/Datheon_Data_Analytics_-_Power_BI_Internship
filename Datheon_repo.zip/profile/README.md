# Hi, I'm Sneha 👋

M.Sc. Statistics student at the University of Mysore, building a career in data analytics with a focus on product analytics.

## Skills
Python (Pandas, Seaborn, Plotly, scikit-learn) | R | SQL | Power BI | DAX | Tableau | SPSS | Excel

## Featured work
- [Datheon Data Analytics & Power BI Internship](https://github.com/Snehagopinath11/Datheon_Data_Analytics_-_Power_BI_Internship): sales analysis, churn modelling, Power BI dashboards and financial variance analysis

## Certifications
Google Data Analytics Professional Certificate | BCG Data Science Job Simulation (Forage)

## Connect
[LinkedIn](https://www.linkedin.com/in/snehagopinath-c-4734a9224)
